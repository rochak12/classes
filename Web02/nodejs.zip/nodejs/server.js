var express = require("express");
var app = express();

// looks for any static page in public directory after root then it response by default
app.use(express.static("public"));


//in views we use ejs where we can use Php HTML and javasctipt 
app.set("views", "ejsViews");
app.set("view engine", "ejs");

app.get("/", function(req, res){
    console.log("Received a request for /");

    res.write ("This is root");
    res.end();
});

app.get("/main.css", function(req, res){

})

app.get("/home", function(req, res){
    console.log("Receiving a request for the home page");
   
    res.render("home");
   // res.write ("This is  not root");
   // res.end();
});

app.listen(8080, function(){
    console.log("Ther server is up and listening at port 8080");
});