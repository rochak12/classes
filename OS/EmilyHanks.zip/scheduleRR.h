/***********************************************************************
* Component:
*    Scheduler RR
* Author:
*    Emily Hanks
* Summary: 
*    This is the base-class that enables various schedule algorithms
*    to simulate CPU Scheduling
************************************************************************/

#ifndef SCHEDULER_RR
#define SCHEDULER_RR

#include "schedule.h"

using namespace std;

/****************************************************
 * RR
 * The Round Robin scheduler
 ***************************************************/
class SchedulerRR : public Disbatcher
{
public:
   SchedulerRR(int q) : Disbatcher(),
      timeQuantaDuration(q), timeCount(0) {}

   // a new process has just been executed. Here we will put it on the
   // back of the ready queue
   void startProcess(int pid)
   {
      readyQueue.push(pid);
   }

   // This function will grab the process in the front of the ready queue
   // and start running it (execute). If there is no process, it will set
   // the current PID to PID_NONE
   void executeFirstProcessInQueue()
   {
      // if there is something on the ready queue, then take the front
      // element. When we do this, we remove the item from the ready queue
      // and place it in pidCurrent.
      if (readyQueue.size())
      {
         pidCurrent = readyQueue.front();
         readyQueue.pop();
         assert(pidCurrent >= 0 && pidCurrent <= processes.size());
      }
      // if there is nothing in the ready queue, then set pidCurrent
      // to none. This means nothing is currently executing in the queue
      else
         pidCurrent = PID_NONE;
   }
      
   // execute one clock cycle
   bool clock()
   {
      // increment our time count
      timeCount++;

      // is the current process finished or is there no process selected?
      if (pidCurrent == PID_NONE ||
          processes[pidCurrent].isDone())
      {
         // Since we've finished with (or don't have) a process, we will
         // now reset our time count
         timeCount = 0;

         // start the process in the front of the queue
         executeFirstProcessInQueue();
      }
      else
      {
         // Here, we have a process currently running. Check if its
         // time quota has been reached
         if (timeCount == timeQuantaDuration)
         {
            // reset the time count because we're grabbing a new process now
            timeCount = 0;

            // The process has run out of time. Add it add the end of the
            // queue and THEN grab the front element to run. (We need to
            // add it back into the queue first in case it is the last
            // process running - otherwise we would lose a clock cycle
            // of computing time)
            readyQueue.push(pidCurrent);

            // start the process in the front of the queue
            executeFirstProcessInQueue();
         }
      }
      
      return Disbatcher::clock();
   }

private:
   // the amount of time given for one quantum of time
   int timeQuantaDuration;

   // the amount of time that has passed in the given quanta
   int timeCount;

   // this will represent the queue of processes which are awaiting
   // execution. We will use a queue because it enforces FIFO order.
   // The data-type is an INT because we are just storing a PID
   std::queue <int> readyQueue;
};

#endif // SCHEDULE_RR
