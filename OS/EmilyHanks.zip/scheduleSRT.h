/***********************************************************************
* Component:
*    Scheduler SRT
* Author:
*    Emily Hanks
* Summary: 
*    This is the base-class that enables various schedule algorithms
*    to simulate CPU Scheduling
************************************************************************/

#ifndef SCHEDULER_SRT
#define SCHEDULER_SRT

#include <list>     // for the collection of processes

#include "schedule.h"


/****************************************************
 * SRT
 * The Shortest Remaining Time Scheduler
 ***************************************************/
class SchedulerSRT : public Disbatcher
{
public:
   SchedulerSRT() : Disbatcher() {}

   // a new process has just been executed
   void startProcess(int pid)
   {
      readyList.push_back(pid);
   }

   // find the process with the least remaining time
   int findShortestProcess()
   {
      if (!readyList.size())
      {
         return -1;
      }

      // search the ready list for the process with the least amount of 
      // time left
      std::list<int>::iterator it;
      int shortestProcess = readyList.front();
      for (it = readyList.begin(); it != readyList.end(); it++)
      {
         if (processes[(*it)].getTimeLeft() < 
             processes[shortestProcess].getTimeLeft())
         {
            shortestProcess = *it;
         }
      }

      return shortestProcess;
   }
   
   // execute one clock cycle
   bool clock()
   {
      // is the current process not finished or is there a process selected?
      if (pidCurrent != PID_NONE && !(processes[pidCurrent].isDone()))
      {
         std::cerr<<"cutting in\n";
         readyList.push_front(pidCurrent);
         pidCurrent = PID_NONE;
      }
      // If there is something on the ready list, then take the process
      // with the least amount of time remaining. When we do this, we 
      // remove the item from the ready list
      if (readyList.size())
      {
         // Set the current process to the shortest process and remove
         // it from our ready list
         pidCurrent = findShortestProcess();
         // std::cerr<<"shortest: "<<pidCurrent<<"\n";
         readyList.remove(pidCurrent);
         assert(pidCurrent >= 0 && pidCurrent <= processes.size());
      }
      // if there is nothing in the ready list, then set pidCurrent
      // to none. This means nothing is currently executing in the list
      else
         pidCurrent = PID_NONE;

      // call the base-class which will handle a variety of housekeeping chores
      return Disbatcher::clock();
   }

private:
   // This will represent the collection of processes that are awaiting 
   // execution. Processes will be entered in order, but might not be
   // executed in that order.
   std::list <int> readyList; 
};

#endif // SCHEDULE_SRT
