/***********************************************************************
* Component:
*    DISK SCHEDULING SSTF
* Author:
*    <your name here>
* Summary: 
*    This is the DERRIVED class to implement the SSTF algorithm
************************************************************************/

#ifndef DS_SSTF
#define DS_SSTF

#include "ds.h"   // for the DiskSchedulingAlgorithm base-class

// using namespace std;

/****************************************************
 * SSTF
 * The Sortest-Seek-Time-First disk scheduling algorithm
 ***************************************************/
class DiskSchedulingSSTF : public DiskSchedulingAlgorithm
{
public:
   /*****************************************************
    * CONSTRUCTOR
    * initialize the data structures specific to SSTF
    *****************************************************/
   DiskSchedulingSSTF(const ScheduleProblem & problem) :
             DiskSchedulingAlgorithm(problem)
   {
      /////////////// YOUR CODE HERE ////////////////////
      requests = problem.requests;
   }

   /****************************************************
    * RUN
    * Implement the algorithm here. This function will only
    * be called once and will need to complete the entire
    * simulation.
    *
    * Each time a disk request is made by setting currentLocation,
    * call record() to save that.
    ***************************************************/
   void run()
   {
      /////////////// YOUR CODE HERE ////////////////////
      while (requests.size() > 0) 
      {
         std::list<int>::iterator lowest = findLowest(currentLocation);
         currentLocation = *lowest;
         record();

         requests.erase(lowest);
      }

      return;
   }

private:
   //////////////////// YOUR CODE HERE //////////////////////
   std::list<int> requests;

   std::list<int>::iterator findLowest(int currentPos)
   {
      std::list<int>::iterator lowest = requests.begin();

      std::list<int>::iterator it;
      for (it = requests.begin(); it != requests.end(); ++it)
      {
         if (abs(currentPos - *lowest) > abs(currentPos - *it))
         {
            lowest = it;
         }
      }

      return lowest;
   }
};

#endif // DS_SSTF
