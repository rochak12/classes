/***********************************************************************
* Component:
*    DISK SCHEDULING LOOK
* Author:
*    <your name here>
* Summary: 
*    This is the DERRIVED class to implement the LOOK algorithm
************************************************************************/

#ifndef DS_LOOK
#define DS_LOOK

#include "ds.h"   // for the DiskSchedulingAlgorithm base-class

// using namespace std;

/****************************************************
 * SCAN
 * The LOOK (SCAN with lookahead) disk scheduling algorithm
 ***************************************************/
class DiskSchedulingLOOK : public DiskSchedulingAlgorithm
{
public:
   /*****************************************************
    * CONSTRUCTOR
    * initialize the data structures specific to SCAN
    *****************************************************/
   DiskSchedulingLOOK(const ScheduleProblem & problem) :
             DiskSchedulingAlgorithm(problem)
   {
      /////////////// YOUR CODE HERE ////////////////////
      requests = problem.requests;
      increasing = problem.increasing;
      diskSize = problem.diskSize;
   }

   /****************************************************
    * RUN
    * Implement the algorithm here. This function will only
    * be called once and will need to complete the entire
    * simulation.
    *
    * Each time a disk request is made by setting currentLocation,
    * call record() to save that.
    ***************************************************/         
   void run()
   {
      /////////////// YOUR CODE HERE ////////////////////
      while (requests.size() > 0)
      {
         std::list<int>::iterator lowest = findNext(currentLocation);
         currentLocation = *lowest;
         record();

         requests.erase(lowest);
      }

      return;
   }

private:
   //////////////////// YOUR CODE HERE //////////////////////
   std::list<int> requests;
   bool increasing;
   int diskSize;

   std::list<int>::iterator findNextHighest(int currentPos, int highest)
   {
      bool foundHigher = false;

      std::list<int>::iterator next = requests.begin();
      std::list<int>::iterator it;
      int nextValue = highest;

      for (it = requests.begin(); it != requests.end(); ++it)
      {
         if (*it >= currentPos)
         {
            // means we found a higher one
            foundHigher = true;
            if (abs(nextValue - currentPos) >= abs(*it - currentPos))
            {
               next = it;
               nextValue = *it;
            }
         }
      }

      if (foundHigher)
      {
         // means a higher one was found and this is the least highest
         return next;
      }
      else
      {
         // means none higher were found
         return requests.end();
      }
   }

   std::list<int>::iterator findNextLowest(int currentPos)
   {
      bool foundLower = false;

      std::list<int>::iterator next = requests.begin();
      std::list<int>::iterator it;
      int nextValue = 0; // lowest possible is always 0

      for (it = requests.begin(); it != requests.end(); ++it)
      {
         if (currentPos >= *it)
         {
            // means we found a lower one
            foundLower = true;
            if (abs(*next - currentPos) >= abs(*it - currentPos))
            {
               next = it;
               nextValue = *it;
            }
         }
      }

      if (foundLower)
      {
         // means a lower one was found and this is the least lowest
         return next;
      }
      else
      {
         // means none lower were found
         return requests.end();
      }
   }

   std::list<int>::iterator findNext(int currentPos)
   {
      std::list<int>::iterator next;
      if (increasing)
      {
         next = findNextHighest(currentPos, diskSize);

         if (next != requests.end())
         {
            return next;
         }
         else
         {
            // this means no higher request was found, reverse and do it again
            increasing = false;
            return findNext(currentPos);
         }
      }
      else
      {
         next = findNextLowest(currentPos);

         if (next != requests.end())
         {
            return next;
         }
         else
         {
            // this means no lower request was found, reverse and do it again
            increasing = true;
            return findNext(currentPos);
         }
      }
   }
};

#endif // DS_LOOK
