/***********************************************************************
* Component:
*    DISK SCHEDULING C-LOOK
* Author:
*    <your name here>
* Summary: 
*    This is the DERRIVED class to implement the C-LOOK algorithm
************************************************************************/

#ifndef DS_C_LOOK
#define DS_C_LOOK

#include "ds.h"   // for the DiskSchedulingAlgorithm base-class

//using namespace std;

/****************************************************
 * C-LOOK
 * The C-LOOK disk scheduling algorithm
 ***************************************************/
class DiskSchedulingC_LOOK : public DiskSchedulingAlgorithm
{
public:
   /*****************************************************
    * CONSTRUCTOR
    * initialize the data structures specific to C-LOOK
    *****************************************************/
   DiskSchedulingC_LOOK(const ScheduleProblem & problem) :
     DiskSchedulingAlgorithm(problem)
   {
      /////////////// YOUR CODE HERE ////////////////////
      requests = problem.requests;
      diskSize = problem.diskSize;
   }

   /****************************************************
    * RUN
    * Implement the algorithm here. This function will only
    * be called once and will need to complete the entire
    * simulation. With file location, send the results to record().
    ***************************************************/
   void run()
   {
      /////////////// YOUR CODE HERE ////////////////////
      while (requests.size() > 0)
      {
         std::list<int>::iterator lowest = findNext();
         currentLocation = *lowest;
         record();

         requests.erase(lowest);
      }

      return;
   }

private:
   //////////////////// YOUR CODE HERE //////////////////////
   std::list<int> requests;
   int diskSize;

   std::list<int>::iterator findNextHighest(int currentPos, int highest)
   {
      bool foundHigher = false;

      std::list<int>::iterator next = requests.begin();
      std::list<int>::iterator it;
      int nextValue = highest;

      for (it = requests.begin(); it != requests.end(); ++it)
      {
         if (*it >= currentPos)
         {
            // means we found a higher one
            foundHigher = true;
            if (abs(nextValue - currentPos) >= abs(*it - currentPos))
            {
               next = it;
               nextValue = *it;
            }
         }
      }

      if (foundHigher)
      {
         // means a higher one was found and this is the least highest
         return next;
      }
      else
      {
         // means none higher were found
         return requests.end();
      }
   }

   std::list<int>::iterator findNext()
   {
      std::list<int>::iterator next;

      next = findNextHighest(currentLocation, diskSize);

      if (next != requests.end())
      {
         return next;
      }
      else
      {
         // this means no higher request was found, reverse and do it again
         currentLocation = 0;
         return findNext();
      }
   }
};

#endif // DS_C_LOOK
